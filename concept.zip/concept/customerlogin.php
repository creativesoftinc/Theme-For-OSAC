<?php

/* 
* Template Name: User Login
*/

get_header();
?>
<header id="fh5co-header" class="fh5co-cover" role="banner" style="background-image:url(images/img_bg_1.jpg);" data-stellar-background-ratio="0.5">
			<div class="overlay"></div>
			<div class="container">
				<div class="row">
					<div class="col-md-7 text-left">
						<div class="display-t">
							<div class="display-tc animate-box" data-animate-effect="fadeInUp">

							<h1 class="mb30"><?php $slug = basename(get_permalink()); 
							echo $slug;  ?></h1>
						</div>
					</div>
				</div>
			</div>
		</div>
	</header>
	<div class="login-form-customer" >
		<center>
	<?php wp_login_form(); ?>
	</center>
</div>


	<?php 
	get_sidebar();
	get_footer(); ?>