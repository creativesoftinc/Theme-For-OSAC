<?php

/* 
* Template Name: Custom Register
*/

get_header();
?>
<header id="fh5co-header" class="fh5co-cover" role="banner" style="background-image:url(images/img_bg_1.jpg);" data-stellar-background-ratio="0.5">
			<div class="overlay"></div>
			<div class="container">
				<div class="row">
					<div class="col-md-7 text-left">
						<div class="display-t">
							<div class="display-tc animate-box" data-animate-effect="fadeInUp">

							<h1 class="mb30"><?php $slug = basename(get_permalink()); 
							echo $slug;  ?></h1>
						</div>
					</div>
				</div>
			</div>
		</div>
	</header>
	<?php
	 //global $wpdb;

	// if ($_POST){


	// 	/*$username = $wpdb->escape($_POST['txtUsername']);
	// 	$email = $wpdb->escape($_POST['txtEmail']);
	// 	$password = $wpdb->escape($_POST['txtPassword']);
	// 	$confpassword = $wpdb->escape($_POST['txtConfirmPassword']);*/

	// 	$error = array();
	// 	if (strpos($username, ' ') !== FALSE){
	// 		$error['username_space'] = "Username has space";
	// 	}
	// 	if(empty($username)){
	// 		$error['Username_empty'] = "Must needed username";
	// 	}
	// 	if(username_exists($username))  {
	// 		$error['username_exists'] = "Username already exists";
	// 	}
	// 	if(!is_email($email)){
	// 		$error['email_valid'] = "Please Enter valid email";
	// 	}
	// 	if(email_exists($email))
	// 	{
	// 		$error['email_existance'] = "Email already exists please use another";
	// 	}

	// 	if (strcmp($password , $confpassword) !== 0){
	// 		$error['password'] = "Password not matched";
	// 	}

	// 	if (count($error) == 0){
	// 		//wp_create_user($fname,$lname,$username,$email,$password);
	// 		echo "User Created Successfully";
	// 		exit();

	// 	}
	// 	else{

	// 	print_r($error);
	// }
/*if ($_POST){
	$fname = $_POST['fname'];
        $lname = $_POST['lname'];
	    $username = $_POST['Username'];
		$email = $_POST['Email'];
		$password = $_POST['Password'];
		$confpassword = $_POST['ConfirmPassword'];
        
		wp_create_user($fname,$lname,$username,$email,$password);
		}*/
	// wp_create_user($fname,$lname,$username,$email,$password);

	?>

	<!-- <form method="post" class="admin-add-user"> -->
		<div class="admin-add-user">
		<p><h1 style="margin-left: 50%">Already Registered &nbsp; &nbsp; &nbsp; <a href="<?php echo get_site_url();?>/log-in/"> Login</a></h1></p>
		<p>
			<label>Enter Your First Name</label>
			<div><input type="text" name="fname"  id="fname" placeholder="firstname"></div>
		</p>
		
			<p>
			<label>Enter Your Last Name</label>
			<div><input type="text" name="lname" id="lname" placeholder="lastname"></div>
		</p>
		
		<p>
			<label>Enter Username for the site</label>
			<div><input type="text" name="Username" id="Username" placeholder="Username"></div>
		</p>
		
		<p>
			<label>Enter Email </label>
			<div><input type="email" name="Email" id="Email" placeholder="Email"></div>
		</p>
		<p>
			<label>Enter Password</label>
			<div><input type="password" name="Password"
				
			id="Password" placeholder="Password"></div>
		
		</p>
		
		<!-- <p>
			<label>Confirm Password</label>
			<div><input type="password" name="ConfirmPassword"
			id="ConfirmPassword" placeholder="Confirm Password"></div>
		</p> -->
		
		<!-- <input type="submit" name="Submit" value="Register"> -->
		
		<button id="add-user" > Create Account </button> 
		
			</div>
		<!-- </form> -->

	<?php 
	get_sidebar();
	get_footer(); ?>