	<?php get_header(); ?>
		<header id="fh5co-header" class="fh5co-cover" role="banner" style="background-image:url(images/img_bg_1.jpg);" data-stellar-background-ratio="0.5">
			<div class="overlay"></div>
			<div class="container">
				<div class="row">
					<div class="col-md-7 text-left">
						<div class="display-t">
							<div class="display-tc animate-box" data-animate-effect="fadeInUp">


							<h1 class="mb30"><?php echo get_the_title(); ?></h1>
						</div>
					</div>
				</div>
			</div>
		</div>
	</header>
<div id="fh5co-blog" class="fh5co-bg-section">
			<div class="container">
				<div class="row animate-box row-pb-md" data-animate-effect="fadeInUp">
					<div class="col-md-8 col-md-offset-2 text-left fh5co-heading">
						<span><?php echo get_theme_mod('blog_pre_title'); ?></span>
						<h2><?php echo get_theme_mod('blog_title'); ?></h2>
						<p><?php echo get_theme_mod('blog_des'); ?></p>
					</div>
				</div>
				
				<div class="row" >
					
		<?php if (current_user_can('administrator')) : ?>				
	<div class="admin-quick-add" >
                            <h3> Quick Add Post </h3>
                            <input type="text" name="title" placeholder="Tilte">
                            <textarea name="content" placeholder="content"></textarea>
                            <button id="quick-add-button"> Create Post </button>
                        </div>
<?php endif; ?>

					<?php
					$json= file_get_contents('https://codepixelz.com/wp-json/wp/v2/posts?per_page=6');
					$posts = json_decode($json);
					foreach ($posts as $p) {
					?>
					<div class="col-md-4 col-sm-4 animate-box common-box" data-animate-effect="fadeInUp">	
						<div class="fh5co-post">
							<span class="fh5co-date"><?php echo $p->date; ?></span>
							<h3><a href="<?php echo 'http://localhost/concept/single_cpm?fp_id='.$p->id; ?>"> <?php echo $p->title->rendered; ?></a></h3>
							<p> <?php echo wp_trim_words($p->content->rendered, 4); ?></p>
							<?php // getting the author name and image
							$ad=file_get_contents('https://codepixelz.com/wp-json/wp/v2/users/'.$p->author);
							$ade=json_decode($ad);
							$y = '96';
                           //print_r($ade->avatar_urls->$y); ?>
                           <p class="author">
                           <img src="<?php echo $ade->avatar_urls->$y; ?>">
                          <cite> <?php echo $ade->name; ?></cite></p>
						</div>
					</div>
					<?php
					//$json_fm= file_get_contents('https://codepixelz.com/wp-json/wp/v2/posts?_embedded');
					//[your-data]._embedded['wp:featuredmedia']['0'].source_url
					
                                   ?>
					
					<!--
					<div class="col-md-4 col-sm-4 animate-box" data-animate-effect="fadeInUp">
						<div class="fh5co-post">
							<span class="fh5co-date">Sep. 23rd</span>
							<h3><a href="#">Web Design for the Future</a></h3>
							<p>Facilis ipsum reprehenderit nemo molestias. Aut cum mollitia reprehenderit. Eos cumque dicta adipisci architecto culpa amet.</p>
							<p class="author"><img src="<?php //bloginfo('stylesheet_directory');?>/images/person1.jpg" alt="Free HTML5 Bootstrap Template by gettemplates.co"> <cite> Mike Adam</cite></p>
						</div>
					</div>
					<div class="col-md-4 col-sm-4 animate-box" data-animate-effect="fadeInUp">
						<div class="fh5co-post">
							<span class="fh5co-date">Sep. 24th</span>
							<h3><a href="#">Web Design for the Future</a></h3>
							<p>Facilis ipsum reprehenderit nemo molestias. Aut cum mollitia reprehenderit. Eos cumque dicta adipisci architecto culpa amet.</p>
							<p class="author"><img src="<?php //bloginfo('stylesheet_directory');?>/images/person1.jpg" alt="Free HTML5 Bootstrap Template by gettemplates.co"> <cite> Mike Adam</cite></p>
						</div>
					</div>
				</div>
			</div>-->
			<?php }//} } ?>
		</div>
	</div>
</div>
<?php get_footer(); ?>