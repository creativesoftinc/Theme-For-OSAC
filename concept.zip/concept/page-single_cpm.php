
<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package concept
 */

get_header();
?>
<header id="fh5co-header" class="fh5co-cover" role="banner" style="background-image:url(images/img_bg_1.jpg);" data-stellar-background-ratio="0.5">
			<div class="overlay"></div>
			<div class="container">
				<div class="row">
					<div class="col-md-7 text-left">
						<div class="display-t">
							<div class="display-tc animate-box" data-animate-effect="fadeInUp">
							<h1 class="mb30">Recent Blogs By OSAC</h1>
						</div>
					</div>
				</div>
			</div>
		</div>
	</header>
	<div id="primary" class="content-area singlepage">
		<main id="main" class="site-main">
<div class="page-title">
	<p>
	<?php
					$fp=$_GET["fp_id"];
					$json_data = file_get_contents('https://codepixelz.com/wp-json/wp/v2/posts/'.$fp.'?_embed');
					$decoded = json_decode($json_data);
					 echo $decoded->title->rendered;
					?>
					</p>
		</div>

			<div class="page-content">
					<?php
					//$json= file_get_contents('https://codepixelz.com/wp-json/wp/v2/posts?_embed');
					//$posts = json_decode($json);

						$fm = 'wp:featuredmedia';
						//foreach ($posts as $p) {
						foreach ($decoded->_embedded->$fm as $fimg) {
						    ?>
		<a href="#"><img class="img-responsive" src="<?php echo $fimg->media_details->sizes->full->source_url; ?>" alt=""></a>
			<?php }
			echo $decoded->content->rendered;
			 ?>

		</div>
		</main><!-- #main -->
	</div><!-- #primary -->

<?php
get_footer();
