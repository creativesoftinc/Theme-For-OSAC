
//quick add form
var quickAddButton = document.querySelector("#quick-add-button");
if(quickAddButton){
    quickAddButton.addEventListener("click", function(){
        ourPostData = {
            "title": document.querySelector('.admin-quick-add [name="title"]').value,
            "content": document.querySelector('.admin-quick-add [name="content"]').value,
            "status" : "publish"
        }
        var createPost = new XMLHttpRequest();
        createPost.open("POST",magicalData.siteURL + "/wp-json/wp/v2/posts");
        createPost.setRequestHeader("X-WP-Nonce", magicalData.nonce);
        createPost.setRequestHeader("Content-Type","application/JSON;charset=UTF-8");
        createPost.send(JSON.stringify(ourPostData));
        createPost.onreadystatechange = function(){
       // if(createPost.readystate == function(){
            if(createPost.readyState == 4){
                if(createPost.status == 201){
                document.querySelector('.admin-quick-add [name="title"]').value = '';
                document.querySelector('.admin-quick-add [name="content"]').value = '';   

                }
                else{
                    alert("Error - try again.");
                }
            }
        }
    }
    );
}



//quick add user
/*var clicked = document.getElementById("add-user");


if(clicked){
 
   clicked.addEventListener("click", function(){
       ourFormData = {
          "first_name" : document.querySelector('.admin-add-user [name="fname"]').value,
          "last_name" : document.querySelector('.admin-add-user [name="lname"]').value,
          "username" : document.querySelector('.admin-add-user [name="Username"]').value,
          "email" : document.querySelector('.admin-add-user [name="Email"]').value,
         "password" : document.querySelector('.admin-add-user [name="Password"]').value,
          "status" : "publish",          
       }
        var userData = {
  'username':'@sandip',
  'password':'workhard'
}

var authRequest = new XMLHttpRequest();
authRequest.open('POST', 'http://localhost/concept/wp-json/jwt-auth/v1/token');
authRequest.setRequestHeader('Content-Type','application/JSON');
authRequest.setRequestHeader('Accept','application/JSON');
authRequest.send(JSON.stringify(userData));
    debugger;
authRequest.onReadystatechange =function() {
  if(authRequest.readystate == 4){

    console.log(authRequest.responseText);
  }
}
});
 }*/
//Quick add user with JWT authentication.
var quickAddForm = document.querySelector("add-user");
if(quickAddForm){
   quickAddForm.addEventListener("click", function(){
       ourFormData = {
          "first_name" : document.querySelector('.admin-add-user [name="fname"]').value,
          "last_name" : document.querySelector('.admin-add-user [name="lname"]').value,
          "username" : document.querySelector('.admin-add-user [name="Username"]').value,
          "email" : document.querySelector('.admin-add-user [name="Email"]').value,
         "password" : document.querySelector('.admin-add-user [name="Password"]').value,
          "status" : "publish",   

            }

       var userData = {
           'username' : '@sandip',
           'password' : 'workhard',
         }

       var baseUrl = document.querySelector('.admin-add-user [name="baseUrl"]').value;
       var authRequest = new XMLHttpRequest();
       authRequest.open("POST", baseUrl+"/wp-json/jwt-auth/v1/token");
       authRequest.setRequestHeader('Content-Type','application/json');
       authRequest.setRequestHeader('Accept','application/json');
       authRequest.send(JSON.stringify(userData));

       authRequest.onreadystatechange = function()
       {

         if(authRequest.readyState == 4){
         console.log(authRequest.responseText);
         var authJson = JSON.parse(authRequest.responseText);
         var token = authJson.token;
         console.log(token);
         }

       var createPost = new XMLHttpRequest();

       createPost.open("POST", baseUrl+"/wp-json/wp/v2/users");
       createPost.setRequestHeader('Authorization','Bearer '+token);
       createPost.setRequestHeader('Content-Type','application/JSON;charset=UTF-8');
       createPost.send(JSON.stringify(ourFormData));

       createPost.onreadystatechange = function(){

            if(createPost.readyState == 4) {
                if(createPost.status== 201){
                     document.querySelector('.admin-add-user [name="fname"]').value = '';
                     document.querySelector('.admin-add-user [name="lname"]').value = '';
                     document.querySelector('.admin-add-user [name="Username"]').value = '';
                     document.querySelector('.admin-add-user [name="Email"]').value = '';
                     document.querySelector('.admin-add-user [name="Password"]').value = '';

                    alert("Sucess");

              }
             else{
                     alert("Error-Try Again.");
               }
           }
        }
   }});
      }
    

       /*console.log(ourFormData);

       var createPost = new XMLHttpRequest();
       createPost.open("POST",magicalData.siteURL + "/wp-json/wp/v2/users");
       createPost.setRequestHeader("X-WP-Nonce", magicalData.nonce);
       createPost.setRequestHeader("Content-Type","application/JSON;charset=UTF-8");
       createPost.send(JSON.stringify(ourFormData));
       createPost.onReadystatechange = function(){
        if(createPost.readystate == 4){
          if(createPost.status == 201){
            document.querySelector('.admin-add-user[name="fname"]').value='';
          document.querySelector('.admin-add-user[name="lname"]').value='';
          document.querySelector('.admin-add-user[name="username"]').value='';
          document.querySelector('.admin-add-user[name="Email"]').value='';
          document.querySelector('.admin-add-user[name="Password"]').value='';
        }
        else{
          alret("Something is wrong !");
        }
       }
     }*/

  /*admin-add-user.reset();*/

    
    
                    


