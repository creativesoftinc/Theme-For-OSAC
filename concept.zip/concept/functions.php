<?php
/* Link CSS and JS files function */
add_theme_support( 'title-tag' );
add_theme_support( 'automatic-feed-links' );
 add_theme_support( "custom-header");
 add_theme_support( "custom-background");

 add_editor_style();
include('customizer.php');
function concept_scripts(){
	wp_enqueue_style('animate',get_template_directory_uri(). '/css/animate.css');

	wp_enqueue_style('icomoon',get_template_directory_uri(). '/css/icomoon.css');

	wp_enqueue_style('bootstrap',get_template_directory_uri(). '/css/bootstrap.css');

	wp_enqueue_style('magnific-popup',get_template_directory_uri(). '/css/magnific-popup.css');

	wp_enqueue_style('style',get_template_directory_uri(). '/css/style.css');

wp_enqueue_script('jquery.min',get_theme_file_uri('/js/jquery.min.js'),array());

wp_enqueue_script('bootstrap.min',get_theme_file_uri('/js/bootstrap.min.js'),array());

	wp_enqueue_script('modernizr-2.6.2.min',get_theme_file_uri('/js/modernizr-2.6.2.min.js'),array(),true);

wp_enqueue_script('jquery.easing.1.3',get_theme_file_uri('/js/jquery.easing.1.3.js'),array(),true);


wp_enqueue_script('jquery.waypoints.min',get_theme_file_uri('/js/jquery.waypoints.min.js'),array(),true);

wp_enqueue_script('jquery.countTo',get_theme_file_uri('/js/jquery.countTo.js'),array(),true);

wp_enqueue_script('jquery.magnific-popup.min',get_theme_file_uri('/js/jquery.magnific-popup.min.js'),array(),true);

wp_enqueue_script('magnific-popup-options',get_theme_file_uri('/js/magnific-popup-options.js'),array(),true);

wp_enqueue_script('jquery.stellar.min',get_theme_file_uri('/js/jquery.stellar.min.js'),array(),true);

	wp_enqueue_script('main',get_theme_file_uri('/js/main.js'),array(),true);
    wp_enqueue_script('first',get_theme_file_uri('/js/first.js'),array(),'20151215', true);

    wp_localize_script('main','magicalData', array('nonce' => wp_create_nonce('wp_rest'),'siteURL' => get_site_url()));

    if ( is_singular() ) wp_enqueue_script( "comment-reply" );
}
add_action('wp_enqueue_scripts','concept_scripts');


require get_template_directory().'/inc/walker-nav.php';

  function register_header_menu() {
  register_nav_menu('header-menu',__( 'Header Menu', 'concept'));
}
add_action( 'init', 'register_header_menu' );


function concept_content_width() {
    // This variable is intended to be overruled from themes.
    // Open WPCS issue: {@link https://github.com/WordPress-Coding-Standards/WordPress-Coding-Standards/issues/1043}.
    // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
    $GLOBALS['content_width'] = apply_filters( 'concept_content_width', 640 );
}
add_action( 'after_setup_theme', 'concept_content_width', 0 );




function custom_post_type() {

// Set UI labels for Custom Post Type
    $labels = array(
        'name'                => _x( 'Recent Projects', 'Post Type General Name', 'concept' ),
        'singular_name'       => _x( 'Recent Project', 'Post Type Singular Name', 'concept' ),
        'menu_name'           => __( 'Recent Project', 'concept' ),
        'parent_item_colon'   => __( 'Parent Recent Project', 'concept' ),
        'all_items'           => __( 'All Recent Project', 'concept' ),
        'view_item'           => __( 'View Recent Project', 'concept' ),
        'add_new_item'        => __( 'Add New Recent Project', 'concept' ),
        'add_new'             => __( 'Add New', 'concept' ),
        'edit_item'           => __( 'Edit Recent Project', 'concept' ),
        'update_item'         => __( 'Update Recent Project', 'concept' ),
        'search_items'        => __( 'Search Recent Project', 'concept' ),
        'not_found'           => __( 'Not Found', 'concept' ),
        'not_found_in_trash'  => __( 'Not found in Trash', 'concept' ),
    );

// Set other options for Custom Post Type

    $args = array(
        'label'               => __( 'recent_projects', 'concept' ),
        'description'         => __( 'Recent Project news and reviews', 'concept' ),
        'labels'              => $labels,
        // Features this CPT supports in Post Editor
        'supports'            => array( 'title', 'editor', 'excerpt', 'author', 'thumbnail', 'comments', 'revisions', 'custom-fields', ),
        // You can associate this CPT with a taxonomy or custom taxonomy.
        'taxonomies'          => array( 'genres','category' ),
        /* A hierarchical CPT is like Pages and can have
        * Parent and child items. A non-hierarchical CPT
        * is like Posts.
        */
        'hierarchical'        => false,
        'public'              => true,
        'show_ui'             => true,
        'show_in_menu'        => true,
        'show_in_nav_menus'   => true,
        'show_in_admin_bar'   => true,
        'menu_position'       => 5,
        'can_export'          => true,
        'has_archive'         => false,
        'exclude_from_search' => false,
        'publicly_queryable'  => true,
        'capability_type'     => 'page',
    );

    // Registering your Custom Post Type
    register_post_type( 'recent_projects', $args );

}

/* Hook into the 'init' action so that the function
* Containing our post type registration is not
* unnecessarily executed.
*/
 add_theme_support( 'post-thumbnails' );
add_action( 'init', 'custom_post_type', 0 );


//Display CPT as a regular post

/*add_action( 'pre_get_posts', 'add_recent_products_to_query' );

function add_recent_products_to_query( $query ) {
    if ( is_home() && $query->is_main_query() )
        $query->set( 'post_type', array( 'post', 'movies' ) );
    return $query;
}*/


function general_cpt() {

// Set UI labels for Custom Post Type
    $labels = array(
        'name'                => _x( 'facts', 'Post Type General Name', 'concept' ),
        'singular_name'       => _x( 'fact', 'Post Type Singular Name', 'concept' ),
        'menu_name'           => __( 'General facts', 'concept' ),
        'parent_item_colon'   => __( 'Parent fact', 'concept' ),
        'all_items'           => __( 'All Facts', 'concept' ),
        'view_item'           => __( 'View Fact', 'concept' ),
        'add_new_item'        => __( 'Add New Fact', 'concept' ),
        'add_new'             => __( 'Add New fact', 'concept' ),
        'edit_item'           => __( 'Edit Fact', 'concept' ),
        'update_item'         => __( 'Update Fact', 'concept' ),
        'search_items'        => __( 'Search Fact', 'concept' ),
        'not_found'           => __( 'Not Found', 'concept' ),
        'not_found_in_trash'  => __( 'Not found in Trash', 'concept' ),
    );

// Set other options for Custom Post Type

    $args = array(
        'label'               => __( 'facts', 'concept' ),
        'description'         => __( 'Fact news and reviews', 'concept' ),
        'labels'              => $labels,
        // Features this CPT supports in Post Editor
        'supports'            => array( 'title', 'editor', 'author', 'thumbnail', 'comments', 'revisions', 'custom-fields', ),
        // You can associate this CPT with a taxonomy or custom taxonomy.
        'taxonomies'          => array( 'genres' ),
        /* A hierarchical CPT is like Pages and can have
        * Parent and child items. A non-hierarchical CPT
        * is like Posts.
        */
        'hierarchical'        => false,
        'public'              => true,
        'show_ui'             => true,
        'show_in_menu'        => true,
        'show_in_nav_menus'   => true,
        'show_in_admin_bar'   => true,
        'menu_position'       => 5,
        'can_export'          => true,
        'has_archive'         => false,
        'exclude_from_search' => false,
        'publicly_queryable'  => true,
        'capability_type'     => 'page',
    );

    // Registering your Custom Post Type
    register_post_type( 'facts', $args );

}

/* Hook into the 'init' action so that the function
* Containing our post type registration is not
* unnecessarily executed.
*/

add_action( 'init', 'general_cpt', 0 );


function alumni_cpt() {

// Set UI labels for Custom Post Type
    $labels = array(
        'name'                => _x( 'Alumnis', 'Post Type General Name', 'concept' ),
        'singular_name'       => _x( 'Alumni', 'Post Type Singular Name', 'concept' ),
        'menu_name'           => __( 'Alumnis', 'concept' ),
        'parent_item_colon'   => __( 'Parent Happy Client', 'concept' ),
        'all_items'           => __( 'All Alumnis', 'concept' ),
        'view_item'           => __( 'View Alumni', 'concept' ),
        'add_new_item'        => __( 'Add New Alumni', 'concept' ),
        'add_new'             => __( 'Add New', 'concept' ),
        'edit_item'           => __( 'Edit Alumni', 'concept' ),
        'update_item'         => __( 'Update Alumni', 'concept' ),
        'search_items'        => __( 'Search Alumni', 'concept' ),
        'not_found'           => __( 'Not Found', 'concept' ),
        'not_found_in_trash'  => __( 'Not found in Trash', 'concept' ),
    );

// Set other options for Custom Post Type

    $args = array(
        'label'               => __( 'alumnis', 'concept' ),
        'description'         => __( 'Alumni news and reviews', 'concept' ),
        'labels'              => $labels,
        // Features this CPT supports in Post Editor
        'supports'            => array( 'title', 'editor', 'excerpt', 'author', 'thumbnail', 'comments', 'revisions', 'custom-fields', ),
        // You can associate this CPT with a taxonomy or custom taxonomy.
        'taxonomies'          => array( 'genres' ),
        /* A hierarchical CPT is like Pages and can have
        * Parent and child items. A non-hierarchical CPT
        * is like Posts.
        */
        'hierarchical'        => false,
        'public'              => true,
        'show_ui'             => true,
        'show_in_menu'        => true,
        'show_in_nav_menus'   => true,
        'show_in_admin_bar'   => true,
        'menu_position'       => 5,
        'can_export'          => true,
        'has_archive'         => false,
        'exclude_from_search' => false,
        'publicly_queryable'  => true,
        'capability_type'     => 'page',
    );

    // Registering your Custom Post Type
    register_post_type( 'alumnis', $args );

}

/* Hook into the 'init' action so that the function
* Containing our post type registration is not
* unnecessarily executed.
*/

add_action( 'init', 'alumni_cpt', 0 );

// CPT For Staffs

function team_cpt() {

// Set UI labels for Custom Post Type
    $labels = array(
        'name'                => _x( 'Teams', 'Post Type General Name', 'concept' ),
        'singular_name'       => _x( 'Team', 'Post Type Singular Name', 'concept' ),
        'menu_name'           => __( 'Members', 'concept' ),
        'parent_item_colon'   => __( 'Parent Team', 'concept' ),
        'all_items'           => __( 'All Members', 'concept' ),
        'view_item'           => __( 'View Team', 'concept' ),
        'add_new_item'        => __( 'Add New Memeber', 'concept' ),
        'add_new'             => __( 'Add New', 'concept' ),
        'edit_item'           => __( 'Edit Member', 'concept' ),
        'update_item'         => __( 'Update team', 'concept' ),
        'search_items'        => __( 'Search Team', 'concept' ),
        'not_found'           => __( 'Not Found', 'concept' ),
        'not_found_in_trash'  => __( 'Not found in Trash', 'concept' ),
    );

// Set other options for Custom Post Type

    $args = array(
        'label'               => __( 'teams', 'concept' ),
        'description'         => __( 'Team news and reviews', 'concept' ),
        'labels'              => $labels,
        // Features this CPT supports in Post Editor
        'supports'            => array( 'title', 'editor', 'author', 'thumbnail', 'comments', 'revisions', 'custom-fields', ),
        // You can associate this CPT with a taxonomy or custom taxonomy.
        'taxonomies'          => array( 'genres' ),
        /* A hierarchical CPT is like Pages and can have
        * Parent and child items. A non-hierarchical CPT
        * is like Posts.
        */
        'hierarchical'        => false,
        'public'              => true,
        'show_ui'             => true,
        'show_in_menu'        => true,
        'show_in_nav_menus'   => true,
        'show_in_admin_bar'   => true,
        'menu_position'       => 5,
        'can_export'          => true,
        'has_archive'         => false,
        'exclude_from_search' => false,
        'publicly_queryable'  => true,
        'capability_type'     => 'page',
    );

    // Registering your Custom Post Type
    register_post_type( 'teams', $args );

}

/* Hook into the 'init' action so that the function
* Containing our post type registration is not
* unnecessarily executed.
*/

add_action( 'init', 'team_cpt', 0 );


/**
 * Register our sidebars and widgetized areas.
 *
 */
function arphabet_widgets_init() {

    register_sidebar( array(
        'name'          => 'Home right sidebar',
        'id'            => 'home_right_1',
        'before_widget' => '<div>',
        'after_widget'  => '</div>',
        'before_title'  => '<h2 class="rounded">',
        'after_title'   => '</h2>',
    ) );

}
add_action( 'widgets_init', 'arphabet_widgets_init' );
?>
<?php
//Footer Menus
function register_footer_menu_1() {
  register_nav_menu('footer_menu_1',__( 'Footer Menu 1' , 'concept' ));
}
add_action( 'init', 'register_footer_menu_1' );


  function register_footer_menu_2() {
  register_nav_menu('footer_menu_2',__( 'Footer Menu 2', 'concept' ));
}
add_action( 'init', 'register_footer_menu_2' );

function register_footer_menu_3() {
  register_nav_menu('footer_menu_3',__( 'Footer Menu 3','concept'));
}
add_action( 'init', 'register_footer_menu_3' );

//adding social icons
function concept_social_array() {

    $social_sites = array(
        'twitter'       => 'twitter_profile',
        'facebook'      => 'facebook_profile',
        'google-plus'   => 'googleplus_profile',
        'pinterest'     => 'pinterest_profile',
        'linkedin'      => 'linkedin_profile',
        'youtube'       => 'youtube_profile',
        'vimeo'         => 'vimeo_profile',
        'tumblr'        => 'tumblr_profile',
        'instagram'     => 'instagram_profile',
        'flickr'        => 'flickr_profile',
        'dribbble'      => 'dribbble_profile',
        'rss'           => 'rss_profile',
        'reddit'        => 'reddit_profile',
        'soundcloud'    => 'soundcloud_profile',
        'spotify'       => 'spotify_profile',
        'vine'          => 'vine_profile',
        'yahoo'         => 'yahoo_profile',
        'behance'       => 'behance_profile',
        'codepen'       => 'codepen_profile',
        'delicious'     => 'delicious_profile',
        'stumbleupon'   => 'stumbleupon_profile',
        'deviantart'    => 'deviantart_profile',
        'digg'          => 'digg_profile',
        'github'        => 'github_profile',
        'hacker-news'   => 'hacker-news_profile',
        'steam'         => 'steam_profile',
        'vk'            => 'vk_profile',
        'weibo'         => 'weibo_profile',
        'tencent-weibo' => 'tencent_weibo_profile',
        '500px'         => '500px_profile',
        'foursquare'    => 'foursquare_profile',
        'slack'         => 'slack_profile',
        'slideshare'    => 'slideshare_profile',
        'qq'            => 'qq_profile',
        'whatsapp'      => 'whatsapp_profile',
        'skype'         => 'skype_profile',
        'wechat'        => 'wechat_profile',
        'xing'          => 'xing_profile',
        'paypal'        => 'paypal_profile',
        'email-form'    => 'email_form_profile'
    );

    return apply_filters( 'concept_social_array_filter', $social_sites );
}

//enqueeing the fonts
function my_load_scripts_styles() {
    wp_enqueue_style( 'font-awesome', get_template_directory_uri() . '/font-awesome/css/font-awesome.min.css' );
}
add_action( 'wp_enqueue_scripts', 'my_load_scripts_styles' );

//adding the function for display
function my_social_icons_output() {

    $social_sites = concept_social_array();

    foreach ( $social_sites as $social_site => $profile ) {

        if ( strlen( get_theme_mod( $social_site ) ) > 0 ) {
            $active_sites[ $social_site ] = $social_site;
        }
    }

    if ( ! empty( $active_sites ) ) {

        echo '<ul class="social-media-icons">';
        foreach ( $active_sites as $key => $active_site ) {
            $class = 'fa fa-' . $active_site; ?>
            <li>
                <a class="<?php echo esc_attr( $active_site ); ?>" target="_blank" href="<?php echo esc_url( get_theme_mod( $key ) ); ?>">
                    <i class="<?php echo esc_attr( $class ); ?>" title="<?php echo esc_attr( $active_site ); ?>"></i>
                </a>
            </li>
        <?php }
        echo "</ul>";
    }
}

//for numeric pagination


function pagination_bar( $query_wp )
{
    $pages = $query_wp->max_num_pages;
    $big = 999999999; // need an unlikely integer
    if ($pages > 1)
    {
        $page_current = max(1, get_query_var('paged'));
           $pl = paginate_links(array(
            'base' => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
            'format' => '?paged=%#%',
            'current' => $page_current,
            'total' => $pages,
            'type'          => 'list',
            'prev_text'          => __('&laquo;' , 'concept'),
            'next_text'          => __('&raquo;','concept'),

        ));

           echo str_replace( "<ul class='page-numbers'>", '<ul class="pagination">', $pl );

    }
}
function is_blog () {
    return ( is_archive() || is_author() || is_category() || is_home() || is_single() || is_tag()) && 'post' == get_post_type();
}
function appencontent($content) {
        if(is_blog()) {

                $content.= "<h4>Thank You for giving your valuable time to read this article </h4>";

        }
        return $content;
}
add_filter ('the_content', 'appencontent');


// Work on woocommerce
/*function concept_add_woocommerce_support() {
    add_theme_support( 'woocommerce' );
}
add_action( 'after_setup_theme', 'concept_add_woocommerce_support' );
*/

// Disabling the add to cart button for the out of stock products
add_filter( 'woocommerce_loop_add_to_cart_link', 'filter_loop_add_to_cart_link', 20, 3 );
function filter_loop_add_to_cart_link( $button, $product, $args = array() ) {
 if( $product->is_in_stock() ) return $button;

 // HERE set your button text (when product is not on stock)
 $button_text = __('Not available', 'woocommerce');

 // HERE set your button STYLING (when product is not on stock)
 $color = "#777";      // Button text color
 $background = "#aaa"; // Button background color


 // Changing and disbling the button when products are not in stock
 $style = 'color:'.$color.';background-color:'.$background.';cursor:not-allowed;';
 return sprintf( '<a class="button disabled" style="%s">%s</a>', $style, $button_text );
}

// Code to Display Content Above Add to Cart @ Single Product Page

/*add_action( 'woocommerce_single_product_summary', 'bbloomer_show_return_policy', 20 );

function bbloomer_show_return_policy() {
    echo '<p class="rtrn">30-day return policy offered. See Terms and Conditions for details.</p>';
}*/


add_action( 'woocommerce_single_product_summary', 'bbloomer_show_return_policy', 20 );

function bbloomer_show_return_policy() {
   echo '<p class="rtrn">Currently, we are re-filling</p>';
}

add_action('rest_api_init', 'wp_rest_user_endpoints');
/**
 * Register a new user
 *
 * @param  WP_REST_Request $request Full details about the request.
 * @return array $args.
 **/
function wp_rest_user_endpoints($request) {
  /**
   * Handle Register User request.
   */
  register_rest_route('wp/v2', 'users/register', array(
    'methods' => 'POST',
    'callback' => 'wc_rest_user_endpoint_handler',
  ));
}
function wc_rest_user_endpoint_handler($request = null) {
  $response = array();
  $parameters = $request->get_json_params();
  $username = sanitize_text_field($parameters['username']);
  $email = sanitize_text_field($parameters['email']);
  $password = sanitize_text_field($parameters['password']);
  // $role = sanitize_text_field($parameters['role']);
  $error = new WP_Error();
  if (empty($username)) {
    $error->add(400, __("Username field 'username' is required.", 'wp-rest-user'), array('status' => 400));
    return $error;
  }
  if (empty($email)) {
    $error->add(401, __("Email field 'email' is required.", 'wp-rest-user'), array('status' => 400));
    return $error;
  }
  if (empty($password)) {
    $error->add(404, __("Password field 'password' is required.", 'wp-rest-user'), array('status' => 400));
    return $error;
  }
  // if (empty($role)) {
  //  $role = 'subscriber';
  // } else {
  //     if ($GLOBALS['wp_roles']->is_role($role)) {
  //      // Silence is gold
  //     } else {
  //    $error->add(405, __("Role field 'role' is not a valid. Check your User Roles from Dashboard.", 'wp_rest_user'), array('status' => 400));
  //    return $error;
  //     }
  // }
  $user_id = username_exists($username);
  if (!$user_id && email_exists($email) == false) {
    $user_id = wp_create_user($username, $password, $email);
    if (!is_wp_error($user_id)) {
      // Ger User Meta Data (Sensitive, Password included. DO NOT pass to front end.)
      $user = get_user_by('id', $user_id);
      // $user->set_role($role);
      $user->set_role('subscriber');
      // WooCommerce specific code
      if (class_exists('WooCommerce')) {
        $user->set_role('customer');
      }
      // Ger User Data (Non-Sensitive, Pass to front end.)
      $response['code'] = 200;
      $response['message'] = __("User '" . $username . "' Registration was Successful", "wp-rest-user");
    } else {
      return $user_id;
    }
  } else {
    $error->add(406, __("Email already exists, please try 'Reset Password'", 'wp-rest-user'), array('status' => 400));
    return $error;
  }
  return new WP_REST_Response($response, 123);
}
//codes for adding buttons using Short-codes.
add_shortcode( 'link', 'concept_button_shortcode' );

function concept_button_shortcode( $atts ) {
       extract( shortcode_atts(
               array(
                       'type' => 'Type',
                       'url' => ''
               ),
               $atts
       ));
       return '<span class="concept-button"><a href="' . $url . '">' . $type . '</a></span>';
}

//Twitter authentication.
require_once("twi/twitteroauth.php");

class Twitter_Login_Widget extends WP_Widget
{
    public function __construct()
    {
        parent::__construct("twitter_login_widget", "Twitter Login", array("description" => __("Display a Twitter Login Button")));
    }

    public function form( $instance )
    {
        // Check values
        if($instance)
        {
            $title = esc_attr($instance['title']);
            $consumer_key = $instance['consumer_key'];
            $consumer_secret = $instance['consumer_secret'];
        }
        else
        {
            $title = '';
            $consumer_key = '';
            $consumer_secret = '';
        }
        ?>

        <p>
            <label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title', 'twitter_login_widget'); ?></label>
            <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" />
        </p>

        <p>
            <label for="<?php echo $this->get_field_id('consumer_key'); ?>"><?php _e('Consumer Key:', 'twitter_login_widget'); ?></label>
            <input type="text" class="widefat" id="<?php echo $this->get_field_id('consumer_key'); ?>" name="<?php echo $this->get_field_name('consumer_key'); ?>" value="<?php echo $consumer_key; ?>" />
        </p>

        <p>
            <label for="<?php echo $this->get_field_id('consumer_secret'); ?>"><?php _e('Consumer Secret:', 'twitter_login_widget'); ?></label>
            <input type="text" class="widefat" id="<?php echo $this->get_field_id('consumer_secret'); ?>" name="<?php echo $this->get_field_name('consumer_secret'); ?>" value="<?php echo $consumer_secret; ?>" />
        </p>

        <p>
            While creating a Twitter app use "<?php echo get_site_url() . '/wp-admin/admin-ajax.php?action=twitter_oauth_callback'  ?>" as callback URL.
        </p>

        <?php
    }

    public function update( $new_instance, $old_instance )
    {
        $instance = $old_instance;
        $instance['title'] = strip_tags($new_instance['title']);
        $instance['consumer_key'] = strip_tags($new_instance['consumer_key']);
        $instance['consumer_secret'] = strip_tags($new_instance['consumer_secret']);

        update_option("twitter_oauth_consumer_key", $new_instance['consumer_key']);
        update_option("twitter_oauth_consumer_secret", $new_instance['consumer_secret']);

        return $instance;
    }

    public function widget( $args, $instance )
    {
        extract($args);

        $title = apply_filters('widget_title', $instance['title']);
        echo $before_widget;

        if($title)
        {
            echo $before_title . $title . $after_title ;
        }

        if(is_user_logged_in())
        {
            ?>
                <a href="<?php echo wp_logout_url( get_permalink() ); ?>" title="Logout"><input type="button" value="Logout" /></a>
            <?php
        }
        else
        {
            ?>
                <a href="<?php echo site_url() . '/wp-admin/admin-ajax.php?action=twitter_oauth_redirect'; ?>"><input type="button" value="Login Using Twitter" /></a>
            <?php
        }




        echo $after_widget;
    }
}
register_widget("Twitter_Login_Widget");
