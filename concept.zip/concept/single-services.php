	<?php
	/**
	 * The template for displaying all single posts
	 *
	 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
	 *
	 * @package concept
	 */

	get_header();
	?>
		<header id="fh5co-header" class="fh5co-cover" role="banner" style="background-image:url(images/img_bg_1.jpg);" data-stellar-background-ratio="0.5">
			<div class="overlay"></div>
			<div class="container">
				<div class="row">
					<div class="col-md-7 text-left">
						<div class="display-t">
							<div class="display-tc animate-box" data-animate-effect="fadeInUp">
							<h1 class="mb30">Our Services</h1>
						</div>
					</div>
				</div>
			</div>
		</div>
	</header>
		<div id="primary" class="content-area singlepage">
			<main id="main" class="site-main">
			<?php
			while ( have_posts() ) :
				the_post();
				?>
	     <p><?php the_title(); ?></p>
				<?php
				the_content();

				the_post_navigation();

			endwhile; // End of the loop.
			?>

			</main><!-- #main -->
		</div><!-- #primary -->

	<?php
	get_footer();
