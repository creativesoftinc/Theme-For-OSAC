<?php
/**
 * The template for displaying all single posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package concept
 */

get_header();
?>
<header id="fh5co-header" class="fh5co-cover" role="banner" style="background-image:url(images/img_bg_1.jpg);" data-stellar-background-ratio="0.5">
			<div class="overlay"></div>
			<div class="container">
				<div class="row">
					<div class="col-md-7 text-left">
						<div class="display-t">
							<div class="display-tc animate-box" data-animate-effect="fadeInUp">
							<h1 class="mb30"><?php $slug = basename(get_permalink());
							echo $slug; ?></h1>
						</div>
					</div>
				</div>
			</div>
		</div>
	</header>
	<div id="primary" class="content-area singlepage">
		<main id="main" class="site-main">
<div class="page-title">
		<?php the_title(); ?>
		</div> <div style="margin-top: 40px;"> <?php
		while ( have_posts() ) :
			the_post(); ?></div>
			<div style="margin-top: 40px;" class="page-content">
			<?php
			the_content(); ?>
		</div>
		<?php
			the_post_navigation();
			// If comments are open or we have at least one comment, load up the comment template.
			if ( comments_open() || get_comments_number() ) :
				comments_template();
			endif;
		endwhile; // End of the loop.
		?>
		</main><!-- #main -->
	</div><!-- #primary -->
<?php
get_footer();
