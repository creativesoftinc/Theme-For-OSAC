<?php get_header(); ?>
		<header id="fh5co-header" class="fh5co-cover" role="banner" style="background-image:url(images/img_bg_1.jpg);" data-stellar-background-ratio="0.5">
			<div class="overlay"></div>
			<div class="container">
				<div class="row">
					<div class="col-md-7 text-left">
						<div class="display-t">
							<div class="display-tc animate-box" data-animate-effect="fadeInUp">
							<h1 class="mb30"><?php echo get_theme_mod('about_page_title');?></h1>
						</div>
					</div>
				</div>
			</div>
		</div>
	</header>
	<div id="fh5co-team">
		<div class="container">
			<div class="row animate-box row-pb-md">
				<div class="col-md-8 col-md-offset-2 text-left fh5co-heading">
					<span><?php echo get_theme_mod('about_pre_title');?></span>
					<h2><?php echo get_theme_mod('about_title');?></h2>
					<p> <?php echo get_theme_mod('about_des'); ?> </p>
				</div>
			</div>
			<div class="row">
				<?php
					$args = array( 'post_type' => 'teams', 'posts_per_page' => 6);
								$the_query = new WP_Query( $args ); ?>
								<?php if ( $the_query->have_posts() ) {?>
								<?php while ( $the_query->have_posts() ) { $the_query->the_post();
					 ?>
				<div class="col-md-4 col-sm-4 animate-box" data-animate-effect="fadeIn">
					<div class="fh5co-staff">
						<?php the_post_thumbnail( array(100, 100) );?>
						<h3><?php the_title(); ?></h3>
						<strong class="role">
					<?php $designation = get_post_meta(get_the_id(), 'Designation', true);
					       $facebook = get_post_meta(get_the_id(), 'Facebook Link', true);
					       $twitter = get_post_meta(get_the_id(), 'Twitter Link', true);
					       $linkedin = get_post_meta(get_the_id(), 'Linkedin Link', true);
					       $github = get_post_meta(get_the_id(), 'Github Link', true);
					?>
					<h4><?php echo $designation ?></h4>
						</strong>
						<p><?php the_content();?></p>
						<ul class="fh5co-social-icons">
							<li><a href="<?php echo $linkedin ?>"><i class="icon-linkedin"></i></a></li>
							<li><a href="<?php echo $twitter ?>"><i class="icon-twitter"></i></a></li>
							<li><a href="<?php echo $github ?>"><i class="icon-github"></i></a></li>
							<li><a href="<?php echo $facebook ?>"><i class="icon-facebook"></i></a></li>
						</ul>
					</div>
				</div>
				 <?php } } ?>
			</div>
		</div>
	</div>
		<div id="fh5co-testimonial" class="fh5co-bg-section">
			<div class="container">
				<div class="row animate-box row-pb-md">
					<div class="col-md-8 col-md-offset-2 text-left fh5co-heading">
						<span>
							<?php echo get_theme_mod('hc_pre_title');?></span>
						<h2><?php echo get_theme_mod('hc_title'); ?></h2>
						<p><?php echo get_theme_mod('hc_des');?>.</p>
					</div>
				</div>
				<div class="row">
					<?php
						$i = 1;
					$args = array( 'post_type' => 'alumnis', 'posts_per_page' => 8);
								$the_query = new WP_Query( $args ); ?>
								<?php if ( $the_query->have_posts() ) {?>
								<?php while ( $the_query->have_posts() ) { $the_query->the_post();
					 ?>
		<?php
								if(sqrt($i) == 1 || sqrt($i) == 2 ){
									$class = "testimonial";
								}
								else{
									$class = "testimonial fh5co-selected";
								}
			 ?>
					<div class="col-md-6 animate-box">
						<div class="<?php echo $class; ?>">
							<blockquote>
								<p><?php the_content(); ?></p>
								<?php $name = get_post_meta(get_the_id(), 'name', true); ?>
								<p class="author"> <?php the_post_thumbnail( array(60, 60) );?>  <cite>&mdash; <?php the_title(); ?></cite></p>
							</blockquote>
						</div>
				</div>
					<?php $i++; } } ?>
			</div>
		</div>
	</div>
		<?php get_footer(); ?>
