	<?php get_header(); ?>
	<header id="fh5co-header" class="fh5co-cover" role="banner" style="background-image:url(images/img_bg_1.jpg);" data-stellar-background-ratio="0.5">
			<div class="overlay"></div>
			<div class="container">
				<div class="row">
					<div class="col-md-7 text-left">
						<div class="display-t">
							<div class="display-tc animate-box" data-animate-effect="fadeInUp">
								<h1 class="mb30"><?php echo get_theme_mod('banner_title'); ?></h1>
								<p>
									<a href="<?php echo get_theme_mod('banner_call_on_site_link'); ?>" target="_blank" class="btn btn-primary"><?php echo get_theme_mod('banner_call_on_site'); ?></a> <em class="or">or</em>
										<a href="<?php echo get_theme_mod('banner_call_on_video_link'); ?>" class="link-watch popup-vimeo"><?php echo get_theme_mod('banner_call_on_video'); ?></a>
								</p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</header>

		<div id="fh5co-services" class="fh5co-bg-section border-bottom">
			<div class="container">
				<div class="row row-pb-md">
					<div class="col-md-8 col-md-offset-2 text-left animate-box" data-animate-effect="fadeInUp">
						<div class="fh5co-heading">
							<span><?php echo get_theme_mod('wd_pre_title');?></span>
							<h2><?php echo get_theme_mod('wd_title');?></h2>
							<p><?php echo get_theme_mod('wd_des'); ?></p>
						</div>
					</div>
				</div>
				<div class="row">
					<?php
					$args = array( 'post_type' => 'facts', 'posts_per_page' => 3 );
								$the_query = new WP_Query( $args ); ?>
								<?php if ( $the_query->have_posts() ) {?>
								<?php while ( $the_query->have_posts() ) { $the_query->the_post();
					 ?>
					<div class="col-md-4 col-sm-6 ">
						<div class="feature-center animate-box" data-animate-effect="fadeInUp">
							<span class="icon">
								<!--Extracting the icon from the custom field -->
								<?php $icon = get_post_meta(get_the_id(), 'icon', true); ?>
								<i class="icon-<?php echo $icon; ?>"></i>
							</span>
							<h3><?php the_title(); ?></h3>
							<p><?php //the_content();
								echo wp_trim_words(get_the_content(), 20); ?></p>
							<p><a href="<?php  the_permalink(); ?>"><?php echo get_theme_mod('wd_excerpt');?></a></p>
						</div>
					</div>
						<?php wp_reset_postdata(); } }?>
									</div>
								</div>
							</div>

		<div id="fh5co-testimonial" class="fh5co-bg-section">
			<div class="container">
				<div class="row animate-box row-pb-md">
					<div class="col-md-8 col-md-offset-2 text-left fh5co-heading">
						<span>
							<?php echo get_theme_mod('hc_pre_title');?></span>
						<h2><?php echo get_theme_mod('hc_title'); ?></h2>
						<p><?php echo get_theme_mod('hc_des');?>.</p>
					</div>
				</div>
				<div class="row">
					<?php
						$i = 1;
					$args = array( 'post_type' => 'alumnis', 'posts_per_page' => 4);
								$the_query = new WP_Query( $args ); ?>
								<?php if ( $the_query->have_posts() ) {?>
								<?php while ( $the_query->have_posts() ) { $the_query->the_post();
					 ?>
		<?php
								if(sqrt($i) == 1 || sqrt($i) == 2 ){
									$class = "testimonial";
								}
								else{
									$class = "testimonial fh5co-selected";
								}
			 ?>
					<div class="col-md-6 animate-box">
						<div class="<?php echo $class; ?>">
							<blockquote>
								<p><?php the_content(); ?></p>
								<?php $name = get_post_meta(get_the_id(), 'name', true); ?>
								<p class="author"> <?php the_post_thumbnail( array(60, 60) );?>  <cite>&mdash; <?php the_title(); ?></cite></p>
							</blockquote>
						</div>
				</div>
					<?php $i++; } } ?>
			</div>
		</div>
	</div>
		<div id="fh5co-counter">
			<div class="container">
				<div class="row animate-box" data-animate-effect="fadeInUp">
					<div class="col-md-8 col-md-offset-2 text-left fh5co-heading">
						<span><?php echo get_theme_mod('ff_pre_title');?></span>
						<h2><?php echo get_theme_mod('ff_title');?></h2>
						<p><?php echo get_theme_mod('ff_des');?></p>
					</div>
				</div>
				<div class="row">
					<div class="col-md-3 col-sm-6 animate-box" data-animate-effect="fadeInLeft">
						<div class="feature-center">
							<span class="icon">
								<i class="ti-download"></i>
							</span>
							<span class="counter"><span class="js-counter" data-from="0" data-to="<?php echo get_theme_mod('ff_download_number'); ?>" data-speed="1500" data-refresh-interval="50">1</span>+</span>
							<span class="counter-label"><?php echo get_theme_mod('ff_download'); ?></span>
						</div>
					</div>
					<div class="col-md-3 col-sm-6 animate-box" data-animate-effect="fadeInLeft">
						<div class="feature-center">
								<span class="icon">
									<i class="ti-face-smile"></i>
								</span>
								<span class="counter"><span class="js-counter" data-from="0" data-to="<?php echo get_theme_mod('ff_happyclient_number'); ?>" data-speed="1500" data-refresh-interval="50">1</span>+</span>
								<span class="counter-label"><?php echo get_theme_mod('ff_happyclient'); ?></span>
							</div>
						</div>
						<div class="col-md-3 col-sm-6 animate-box" data-animate-effect="fadeInLeft">
							<div class="feature-center">
								<span class="icon">
									<i class="ti-briefcase"></i>
								</span>
								<span class="counter"><span class=" js-counter" data-from="0" data-to="<?php echo get_theme_mod('ff_project_number'); ?>" data-speed="1500" data-refresh-interval="50">1</span>+</span>
								<span class="counter-label"><?php echo get_theme_mod('ff_projects'); ?></span>
							</div>
						</div>
						<div class="col-md-3 col-sm-6 animate-box" data-animate-effect="fadeInLeft">
							<div class="feature-center">
								<span class="icon">
									<i class="ti-time"></i>
								</span>
								<span class="counter"><span class="js-counter" data-from="0" data-to="<?php echo get_theme_mod('ff_hourspent_number'); ?>" data-speed="1500" data-refresh-interval="50">1</span>+</span>
								<span class="counter-label"><?php echo get_theme_mod('ff_hourspent'); ?></span>
							</div>
						</div>
					</div>
				</div>
		</div>
				<div id="fh5co-blog" class="fh5co-bg-section">
					<div class="container">
						<div class="row animate-box row-pb-md" data-animate-effect="fadeInUp">
							<div class="col-md-8 col-md-offset-2 text-left fh5co-heading">
								<span><?php echo get_theme_mod('blog_pre_title'); ?></span>
								<h2><?php echo get_theme_mod('blog_title'); ?></h2>
								<p><?php echo get_theme_mod('blog_des'); ?></p>
							</div>
						</div>
						<div class="row" >
							<?php
							$args = array( 'post_type' => 'post', 'posts_per_page' => 3);
										$the_query = new WP_Query( $args ); ?>
										<?php if ( $the_query->have_posts() ) {?>
										<?php while ( $the_query->have_posts() ) { $the_query->the_post();
							?>
							<div class="col-md-4 col-sm-4 animate-box" data-animate-effect="fadeInUp">
								<div class="fh5co-post">
									<span class="fh5co-date"><?php echo get_the_date(); ?></span>
									<h3><a href="<?php  the_permalink(); ?>"><?php the_title(); ?></a></h3>
									<?php echo wp_trim_words(get_the_content(),20); ?>
									<p class="author"><?php // getting the author name and image
									$avatar = get_avatar( get_the_author_meta( 'ID' ), 56 );
									if($avatar):
		                            echo $avatar; ?>
		                       <?php else: ?>
		                           <img src="/images/no-image-default.jpg">
		                       <?php endif; ?><cite> <?php the_author(); ?></cite></p>
		                       <?php //echo  get_avatar( get_the_author_meta( 'ID' ) ) ?></p>
								</div>
							</div>
					<?php } } ?>
				</div>
			</div>
		</div>
		<?php get_footer(); ?>
