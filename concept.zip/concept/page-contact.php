	<?php get_header(); ?>
		<header id="fh5co-header" class="fh5co-cover" role="banner" style="background-image:url(images/img_bg_1.jpg);" data-stellar-background-ratio="0.5">
			<div class="overlay"></div>
			<div class="container">
				<div class="row">
					<div class="col-md-7 text-left">
						<div class="display-t">
							<div class="display-tc animate-box" data-animate-effect="fadeInUp">
							<h1 class="mb30"><?php echo get_theme_mod('contact_title'); ?></h1>
						</div>
					</div>
				</div>
			</div>
		</div>
	</header>
	<div id="fh5co-contact">
		<div class="container">
			<div class="row">
				<div class="col-md-5 col-md-push-1 animate-box">
					<div class="fh5co-contact-info">
						<h3><?php echo get_theme_mod('contact_infotitle'); ?> </h3>
						<ul>
							<li class="address"><?php echo  get_theme_mod('contact_localadd'); ?> <br> <?php echo get_theme_mod('contact_countryadd'); ?></li>
							<li class="phone"><a href="<?php echo get_theme_mod('contact_number'); ?>"><?php echo get_theme_mod('contact_number'); ?></a></li>
							<li class="email"><a href="<?php echo get_theme_mod('contact_email'); ?>"><?php echo get_theme_mod('contact_email'); ?></a></li>
							<li class="url"><a href="<?php echo get_theme_mod('contact_website'); ?>"><?php echo get_theme_mod('contact_website_text'); ?></a></li>
						</ul>
					</div>
				</div>
				<div class="col-md-6 animate-box">
					<h3><?php echo get_theme_mod('form_title'); ?></h3>
					<?php  echo do_shortcode('[contact-form-7 id="212" title="Get In Touch"]'); ?>
				</div>
			</div>
		</div>
	</div>
		<?php get_footer(); ?>
