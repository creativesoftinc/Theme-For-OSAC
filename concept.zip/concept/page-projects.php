					<?php get_header(); ?>
						<header id="fh5co-header" class="fh5co-cover" role="banner" style="background-image:url(images/img_bg_1.jpg);" data-stellar-background-ratio="0.5">
							<div class="overlay"></div>
							<div class="container">
								<div class="row">
									<div class="col-md-7 text-left">
										<div class="display-t">
											<div class="display-tc animate-box" data-animate-effect="fadeInUp">
											<h1 class="mb30">Our Creative Projects</h1>
										</div>
									</div>
								</div>
							</div>
						</div>
					</header>
					<div id="fh5co-project">
			<div class="container">
				<div class="row row-pb-md">
					<div class="col-md-8 col-md-offset-2 text-left fh5co-heading  animate-box">
						<span><?php echo get_theme_mod('pre_title');?></span>
						<h2><?php echo get_theme_mod('rp_title'); ?></h2>
						<p><?php echo get_theme_mod('rp_des');?></p>
					</div>
				</div>
							<div class="row">
								<?php
								$paged = ( get_query_var( 'paged' ) ) ? get_query_var( 'paged' ) : 2;
								$args = array('post_type'=>'recent_projects','posts_per_page' => 3,'paged' => $paged);
								$the_query = new WP_Query($args);
								if ( $the_query->have_posts() ):
								    while ( $the_query->have_posts() ) : $the_query->the_post(); ?>

									<div class="col-md-4 col-sm-6 fh5co-project animate-box" data-animate-effect="fadeIn">
										<a href="<?php  the_permalink(); ?>">
																<?php
																//the_post_thumbnail( 'thumbnail' );     // Thumbnail (150 x 150 hard cropped)
							                                        the_post_thumbnail( array(500,250
							                                        ) );     ?> <?php //endif;
							                                           // Medium resolution (300 x 300 max height 300px)?>
											<div class="fh5co-copy">
												<h3><?php the_title(); ?></h3>
												<p><?php //the_content();
												echo wp_trim_words(get_the_content(), 10); ?></p>
											</div>
										</a>
									</div>
										<?php endwhile; ?>
								<div class="col-md-12 text-center">
									<nav aria-label="Page navigation">
									 <!--  <ul class="pagination"> -->
									  	<?php pagination_bar( $the_query );
									  	 ?>
									</nav>
									<?php wp_reset_postdata();
									 endif; ?>
								</div>
							</div>
						</div>
					</div>
						<?php get_footer(); ?>
