<?php get_header(); ?>
		<header id="fh5co-header" class="fh5co-cover" role="banner" style="background-image:url(images/img_bg_1.jpg);" data-stellar-background-ratio="0.5">
			<div class="overlay"></div>
			<div class="container">
				<div class="row">
					<div class="col-md-7 text-left">
						<div class="display-t">
							<div class="display-tc animate-box" data-animate-effect="fadeInUp">
							<h1 class="mb30">Code Of Conducts</h1>
						</div>
					</div>
				</div>
			</div>
		</div>
	</header>
  <div id="primary" class="content-area">
		<main id="main" class="site-main">
  <?php if ( have_posts() ) :
    while ( have_posts() ) : the_post();
        // Your loop code
        the_content();
    endwhile;
else :
    _e( 'Sorry, no posts were found.', 'textdomain' );
endif;
?>
</main>
</div>
<?php
get_sidebar();
get_footer();
